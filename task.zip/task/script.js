
// Projects Javascript 
document.addEventListener('DOMContentLoaded', function() {
    const slidesContainer = document.querySelector('.slides-container');
    let currentIndex = 0;
    const totalSlides = document.querySelectorAll('.location-image').length;

    function getVisibleSlides() {
        return window.innerWidth <= 768 ? 1 : 3; // Mobile me 1 slide, desktop me 3 slides
    }

    function slideNext() {
        const visibleSlides = getVisibleSlides();
        currentIndex = (currentIndex + 1) % (totalSlides - visibleSlides + 1);
        const translateX = -(currentIndex * (100 / visibleSlides));
        slidesContainer.style.transform = `translateX(${translateX}%)`;
    }

    // Start automatic sliding
    setInterval(slideNext, 2000);

    // Adjust slides on window resize
    window.addEventListener('resize', () => {
        currentIndex = 0; // Resize hone par slide reset ho jaye
        slidesContainer.style.transform = `translateX(0%)`;
    });
});



// Projects Javascript 

// Navbar css 
document.addEventListener("DOMContentLoaded", function () {
    // Burger menu toggle for mobile responsiveness
    let burger = document.querySelector('.burger');
    let nav = document.querySelector('nav');

    burger.addEventListener('click', function() {
        this.classList.toggle('active');
        nav.classList.toggle('active');
    });

    // Dropdown menu handling
    let dropdowns = document.querySelectorAll(".dropdown > a");

    dropdowns.forEach(drop => {
        drop.addEventListener("click", function (event) {
            event.preventDefault();
            let menu = this.nextElementSibling;

            // Hide all dropdowns first
            document.querySelectorAll(".dropdown-menu").forEach(m => {
                if (m !== menu) m.classList.remove("show");
            });

            // Toggle the current dropdown
            menu.classList.toggle("show");
        });
    });

    document.addEventListener("click", function (e) {
        if (!e.target.closest(".dropdown") && !e.target.closest(".burger")) {
            document.querySelectorAll(".dropdown-menu").forEach(m => m.classList.remove("show"));
        }
    });
});

// Navbar css 


// Show popup after 3 seconds
window.onload = function() {
    setTimeout(openPopup, 3000);
};

function openPopup() {
    const popup = document.getElementById('popup');
    const content = document.querySelector('.popup-content');
    popup.style.display = 'flex';
    setTimeout(() => content.classList.add('active'), 10);
}

function closePopup() {
    const popup = document.getElementById('popup');
    const content = document.querySelector('.popup-content');
    content.classList.remove('active');
    setTimeout(() => popup.style.display = 'none', 300);
}

// Close popup when clicking outside
document.getElementById('popup').addEventListener('click', function(e) {
    if (e.target === this) closePopup();
});



